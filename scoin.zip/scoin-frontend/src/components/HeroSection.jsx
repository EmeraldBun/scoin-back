import { useState } from 'react'

function HeroSection({ onLogin }) {
  const [loginData, setLoginData] = useState({ login: '', password: '' })
  const [error, setError] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Ошибка входа')
      localStorage.setItem('token', data.token)
      onLogin(data.user)
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="text-center px-4 py-12 sm:py-16 max-w-sm mx-auto">
      <img
        src="/coin.gif"
        alt="Coin"
        className="mx-auto w-20 h-20 sm:w-24 sm:h-24 mb-6 animate-bounce"
      />
      <h1 className="text-2xl sm:text-3xl font-bold text-white mb-4">
        Вход в систему
      </h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Логин"
          value={loginData.login}
          onChange={(e) => setLoginData({ ...loginData, login: e.target.value })}
          className="w-full px-3 py-2 rounded bg-zinc-800 border border-zinc-600 text-white"
        />
        <input
          type="password"
          placeholder="Пароль"
          value={loginData.password}
          onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
          className="w-full px-3 py-2 rounded bg-zinc-800 border border-zinc-600 text-white"
        />
        {error && <div className="text-red-500 text-sm">{error}</div>}
        <button className="w-full bg-purple-700 hover:bg-purple-800 text-white py-2 rounded">
          Войти
        </button>
      </form>
    </div>
  )
}

export default HeroSection
