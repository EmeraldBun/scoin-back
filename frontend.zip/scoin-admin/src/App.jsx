import { useEffect, useState } from 'react'

function App() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [loginData, setLoginData] = useState({ login: '', password: '' })
  const [token, setToken] = useState('')
  const [users, setUsers] = useState([])
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('dashboard')
  const isAdmin = localStorage.getItem('is_admin') === 'true'
  const [purchases, setPurchases] = useState([])



  const handleLogin = async () => {
    try {
      const res = await fetch('http://localhost:3000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData),
      })
      const data = await res.json()
      if (data.token) {
        localStorage.setItem('token', data.token)
        localStorage.setItem('is_admin', data.user.is_admin)
        setToken(data.token)
        setLoggedIn(true)      
      } else {
        alert('Ошибка авторизации')
      }
    } catch (err) {
      alert('Ошибка подключения к серверу')
    }
  }

  const fetchUsers = async () => {
    try {
      const res = await fetch('http://localhost:3000/api/users', {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      setUsers(data)
    } catch (err) {
      console.error('Ошибка загрузки пользователей:', err)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('is_admin')
    setToken('')
    setLoggedIn(false)
  }  

  const fetchItems = async () => {
    try {
      const res = await fetch('http://localhost:3000/api/items', {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      setItems(data)
    } catch (err) {
      console.error('Ошибка загрузки товаров:', err)
    }
  }

  const giveCoins = async (userId) => {
    await fetch(`http://localhost:3000/api/users/${userId}/coins`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ amount: 100 }),
    })
    fetchUsers()
  }

  const deleteItem = async (itemId) => {
    await fetch(`http://localhost:3000/api/items/${itemId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    })
    fetchItems()
  }

  const buyItem = async (itemId) => {
    const res = await fetch('http://localhost:3000/api/buy', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ item_id: itemId }),
    })
  
    const data = await res.json()
  
    if (res.ok) {
      alert('Покупка успешна')
      fetchItems()
      fetchPurchases()
    } else {
      alert(data.error || 'Ошибка при покупке')
    }
  }

  const fetchPurchases = async () => {
    const res = await fetch('http://localhost:3000/api/my-purchases', {
      headers: { Authorization: `Bearer ${token}` },
    })
    const data = await res.json()
    setPurchases(data)
  }    

  const deleteUser = async (id) => {
    if (!window.confirm('Удалить пользователя?')) return
  
    const res = await fetch(`http://localhost:3000/api/users/${id}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  
    if (res.ok) {
      fetchUsers()
    } else {
      alert('Ошибка при удалении')
    }
  }
  
  useEffect(() => {
    const savedToken = localStorage.getItem('token')
    if (savedToken) {
      setToken(savedToken)
      setLoggedIn(true)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    if (loggedIn) {
      fetchUsers()
      fetchItems()
      fetchPurchases()
    }
  }, [loggedIn])

  if (loading) {
    return <div className="p-8 text-center text-lg">Загрузка...</div>
  }

  if (!loggedIn) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-100">
        <div className="bg-white shadow-lg rounded-xl p-8 w-full max-w-sm space-y-4">
          <div>
            <label className="block font-semibold mb-1">Логин</label>
            <input
              className="w-full border rounded px-3 py-2"
              value={loginData.login}
              onChange={(e) => setLoginData({ ...loginData, login: e.target.value })}
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">Пароль</label>
            <input
              type="password"
              className="w-full border rounded px-3 py-2"
              value={loginData.password}
              onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
            />
          </div>
          <button
            onClick={handleLogin}
            className="bg-blue-600 text-white w-full py-2 rounded hover:bg-blue-700 transition"
          >
            Войти
          </button>
        </div>
      </div>
    )
  }

  const userId = token ? JSON.parse(atob(token.split('.')[1])).id : null
  const user = users.find((u) => u.id === userId)
  const balance = user?.balance ?? 0

  return (
    <div className="min-h-screen bg-red-500 text-white p-6">
      <div className="bg-monobank text-hacker p-4 shadow-neon text-2xl rounded mb-4">
  🎯 Tailwind кастом работает!
</div>

      <h1 className="text-4xl font-bold mb-6 shadow-neon">💰 Добро пожаловать в S-Coin</h1>

      <button
        onClick={handleLogout}
        className="mb-4 bg-hacker text-black px-4 py-2 rounded hover:opacity-90 shadow-neon"
      >
        Выйти
      </button>

      <p className="mb-4 text-lg text-gray-700">
        Ваш баланс: <span className="font-bold">{balance}</span> S-Coin
      </p>

      <nav className="flex gap-2 mb-6 flex-wrap">
        <button
          onClick={() => setTab('dashboard')}
          className={tab === 'dashboard' ? 'bg-purple-600 text-white px-4 py-2 rounded' : 'bg-gray-800 text-white px-4 py-2 rounded'}
        >
          🏠 Дашборд
        </button>
        <button
          onClick={() => setTab('shop')}
          className={tab === 'shop' ? 'bg-purple-600 text-white px-4 py-2 rounded' : 'bg-gray-800 text-white px-4 py-2 rounded'}
        >
          🛒 Магазин
        </button>
        <button
          onClick={() => setTab('purchases')}
          className={tab === 'purchases' ? 'bg-purple-600 text-white px-4 py-2 rounded' : 'bg-gray-800 text-white px-4 py-2 rounded'}
        >
          📦 Мои покупки
        </button>
        {isAdmin && (
          <button
            onClick={() => setTab('admin')}
            className={tab === 'admin' ? 'bg-purple-600 text-white px-4 py-2 rounded' : 'bg-gray-800 text-white px-4 py-2 rounded'}
          >
            👥 Админка
          </button>
        )}
      </nav>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

        {tab === 'dashboard' && (
          <div className="min-h-screen bg-monobank text-hacker font-mono p-6">
  <h1 className="text-4xl font-bold mb-6 shadow-neon">💰 Добро пожаловать в S-Coin</h1>
          </div>
        )}

        {tab === 'shop' && (
          <div className="bg-white rounded-xl shadow p-4 col-span-2">
            <h2 className="text-xl font-semibold mb-4">Каталог</h2>
            <ul className="space-y-2">
              {items.map((item) => (
                <li key={item.id} className="border p-3 rounded flex justify-between items-center">
                  <div>
                    <p className="font-bold">{item.name}</p>
                    <p className="text-sm">{item.description}</p>
                    <p className="text-sm text-gray-600">{item.price} S-Coin</p>
                  </div>
                  <div className="flex gap-2">
                    {item.image_url && (
                      <img src={item.image_url} className="h-12 w-12 object-cover rounded" />
                    )}
                    <button
                      onClick={() => buyItem(item.id)}
                      className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
                    >
                      Купить
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {tab === 'purchases' && (
          <div className="bg-white rounded-xl shadow p-4 col-span-2">
            <h2 className="text-xl font-semibold mb-4">Мои покупки</h2>
            <ul className="space-y-2">
              {purchases.length === 0 && (
                <p className="text-gray-500">Пока ничего не куплено</p>
              )}
              {purchases.map((p, i) => (
                <li key={i} className="border p-3 rounded flex justify-between items-center">
                  <div>
                    <p className="font-bold">{p.name}</p>
                    <p className="text-sm">{p.price} S-Coin</p>
                    <p className="text-xs text-gray-500">
                      Куплено: {new Date(p.created_at).toLocaleString()}
                    </p>
                  </div>
                  {p.image_url && (
                    <img src={p.image_url} className="h-12 w-12 object-cover rounded" />
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}

        {isAdmin && tab === 'admin' && (
          <>
            {/* Пользователи */}
            <div className="bg-white rounded-xl shadow p-4">
              <h2 className="text-xl font-semibold mb-2">Пользователи</h2>
              <table className="w-full text-left border mt-2">
                <thead>
                  <tr>
                    <th className="p-2 border">Имя</th>
                    <th className="p-2 border">Баланс</th>
                    <th className="p-2 border">Действие</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id}>
                      <td className="p-2 border">{u.name}</td>
                      <td className="p-2 border">{u.balance}</td>
                      <td className="p-2 border">
                        <button
                          onClick={() => giveCoins(u.id)}
                          className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
                        >
                          +100 S-Coin
                        </button>
                        <button
                          onClick={() => deleteUser(u.id)}
                          className="ml-2 bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                        >
                          Удалить
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-2">Создать пользователя</h3>
              <form
                onSubmit={async (e) => {
                  e.preventDefault()
                  const form = e.target
                  const newUser = {
                    login: form.login.value,
                    password: form.password.value,
                    name: form.name.value,
                    is_admin: form.is_admin.checked,
                  }

                  const res = await fetch('http://localhost:3000/api/register', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify(newUser),
                  })

                  if (res.ok) {
                    form.reset()
                    alert('Пользователь создан')
                    fetchUsers()
                  } else {
                    alert('Ошибка при создании')
                  }
                }}
                className="space-y-2 mt-4"
              >
                <input name="login" placeholder="Логин" className="border p-2 w-full" required />
                <input name="password" type="password" placeholder="Пароль" className="border p-2 w-full" required />
                <input name="name" placeholder="Имя" className="border p-2 w-full" required />
                <label className="flex items-center gap-2">
                  <input name="is_admin" type="checkbox" />
                  Админ
                </label>
                <button className="bg-purple-600 text-white px-4 py-2 rounded">Создать</button>
              </form>
            </div>

            {/* Товары */}
            <div className="bg-white rounded-xl shadow p-4">
              <h2 className="text-xl font-semibold mb-4">Товары</h2>
              <form
                onSubmit={async (e) => {
                  e.preventDefault()
                  const form = e.target
                  const newItem = {
                    name: form.name.value,
                    price: parseInt(form.price.value),
                    image_url: form.image_url.value,
                    description: form.description.value,
                  }

                  const res = await fetch('http://localhost:3000/api/items', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify(newItem),
                  })

                  if (res.ok) {
                    form.reset()
                    fetchItems()
                  } else {
                    alert('Ошибка при добавлении товара')
                  }
                }}
                className="space-y-2 mb-4"
              >
                <input name="name" placeholder="Название" className="border p-2 w-full" required />
                <input name="price" type="number" placeholder="Цена" className="border p-2 w-full" required />
                <input name="image_url" placeholder="URL картинки" className="border p-2 w-full" />
                <input name="description" placeholder="Описание" className="border p-2 w-full" />
                <button className="bg-blue-600 text-white px-4 py-2 rounded">Добавить товар</button>
              </form>

              <ul className="space-y-2">
                {items.map((item) => (
                  <li key={item.id} className="border p-3 rounded flex justify-between items-center">
                    <div>
                      <p className="font-bold">{item.name}</p>
                      <p className="text-sm">{item.description}</p>
                      <p className="text-sm text-gray-600">{item.price} S-Coin</p>
                    </div>
                    <div className="flex gap-2">
                      {item.image_url && (
                        <img src={item.image_url} className="h-12 w-12 object-cover rounded" />
                      )}
                      <button
                        onClick={() => deleteItem(item.id)}
                        className="text-red-600 border border-red-600 px-2 rounded hover:bg-red-100"
                      >
                        Удалить
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

export default App
