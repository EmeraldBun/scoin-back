/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        mono: ['"Fira Code"', 'monospace'],
      },
      colors: {
        monobank: '#1a1a1a',
        hacker: '#00ff88',
      },
      boxShadow: {
        neon: '0 0 10px #00ff88',
      },
    },
  },
  plugins: [],
}
